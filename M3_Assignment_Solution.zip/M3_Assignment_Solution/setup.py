#Creating a Package Setup File

from setuptools import setup

setup(name='My_package', version='1.0',
description='A package to calculate points for cricket players',
url='#',
author='Sunanda Mahanta',
author_email='mahanta.sunanda28@gmail.com',
license='SVCE',
packages=['My_package'],
zip_safe=False)
